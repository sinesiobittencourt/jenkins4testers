class BasePage
  include Capybara::DSL
end
